# MPG — Private Gallery (Android starter project)

A dark-theme Android gallery starter with:
- 6-digit PIN setup and unlock
- Android biometric prompt (fingerprint where supported/enrolled)
- Photo and video import using Android's system photo picker
- Imported media encrypted with AES-GCM using an Android Keystore key
- App-private storage; no broad photo-library permission
- Delete imported items and manual Lock button

## Open and build
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync to complete.
4. Connect an Android device (API 26+) or start an emulator.
5. Select **Build > Build APK(s)**. The debug APK is usually at `app/build/outputs/apk/debug/app-debug.apk`.

## Important notes
- This is a starter project, not a signed Play Store release.
- Fingerprint works only if the device has a supported biometric sensor and fingerprint enrolled.
- Imported copies are encrypted in MPG's private app storage. The original files remain in the phone's normal gallery; delete those separately if you want them removed there too.
- Android may clear app cache at any time. This app decrypts temporary previews into cache while unlocked.
- The starter uses a 6-digit PIN hash for local gating. For a production release, add rate limiting, secure PIN reset/recovery, encrypted backups, video playback, image zoom, and independent security testing.
- Uninstalling the app or clearing its data deletes the vault key and encrypted media; export anything you want to keep first.

## Added in this update
- Tap a private video tile to open an in-app video preview/player.
- Tap a private photo tile to preview it, rotate it in 90-degree steps, and save the rotated copy back into encrypted vault storage.


## Build APK from a phone (cloud build)
This project includes a GitHub Actions workflow at `.github/workflows/android-apk.yml`.
1. Create a GitHub repository from your phone.
2. Upload the **contents** of this project (extract the ZIP first; include the `.github` folder).
3. Open the repository's **Actions** tab and run **Build MPG Android APK** (or push to `main`).
4. Open the completed workflow run, download the `MPG-debug-APK` artifact, extract it, and install `app-debug.apk`.
5. On Android 13, allow installation from the browser or file manager when prompted.

The cloud workflow builds a debug APK. It is suitable for testing, not a signed Play Store release.
