package com.mpg.privategallery

import android.os.Bundle
import android.net.Uri
import android.content.Context
import android.util.Base64
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.PickVisualMediaRequest
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.io.File
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties

private val Bg = Color(0xFF101116)
private val Panel = Color(0xFF1B1D25)
private val Accent = Color(0xFF9B87F5)
private val Txt = Color(0xFFF4F2FA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MPGApp() }
    }
}

private fun key(): SecretKey {
    val ks = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    (ks.getEntry("mpg_media_key", null) as? java.security.KeyStore.SecretKeyEntry)?.let { return it.secretKey }
    val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
    gen.init(KeyGenParameterSpec.Builder(
        "mpg_media_key",
        KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
    ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
        .setRandomizedEncryptionRequired(true)
        .build())
    return gen.generateKey()
}

private fun saveEncrypted(context: Context, uri: Uri, isVideo: Boolean): File {
    val input = context.contentResolver.openInputStream(uri) ?: error("Cannot read selected file")
    val bytes = input.use { it.readBytes() }
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.ENCRYPT_MODE, key())
    val encrypted = cipher.doFinal(bytes)
    val out = File(context.filesDir, "vault").apply { mkdirs() }
    val file = File(out, "${System.currentTimeMillis()}_${if (isVideo) "video" else "photo"}.mpg")
    file.outputStream().use {
        it.write(cipher.iv.size)
        it.write(cipher.iv)
        it.write(encrypted)
    }
    return file
}

private fun decryptToCache(context: Context, file: File): File? = try {
    val bytes = file.readBytes()
    val ivSize = bytes[0].toInt()
    val iv = bytes.copyOfRange(1, 1 + ivSize)
    val encrypted = bytes.copyOfRange(1 + ivSize, bytes.size)
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
    val clear = cipher.doFinal(encrypted)
    val ext = if (file.name.contains("video")) ".mp4" else ".jpg"
    val cache = File(context.cacheDir, file.nameWithoutExtension + ext)
    cache.writeBytes(clear)
    cache
} catch (_: Exception) { null }

private fun replaceEncrypted(context: Context, target: File, clearBytes: ByteArray) {
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.ENCRYPT_MODE, key())
    val encrypted = cipher.doFinal(clearBytes)
    target.outputStream().use {
        it.write(cipher.iv.size)
        it.write(cipher.iv)
        it.write(encrypted)
    }
}

@Composable
fun MPGApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("mpg", Context.MODE_PRIVATE) }
    var pin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var entered by remember { mutableStateOf("") }
    var unlocked by remember { mutableStateOf(false) }
    var setup by remember { mutableStateOf(!prefs.contains("pin_hash")) }
    var error by remember { mutableStateOf("") }
    var files by remember { mutableStateOf(listOf<File>()) }
    var previews by remember { mutableStateOf<Map<String, File>>(emptyMap()) }
    var selectedFile by remember { mutableStateOf<File?>(null) }
    var rotation by remember { mutableIntStateOf(0) }

    fun refresh() {
        val dir = File(context.filesDir, "vault")
        files = dir.listFiles()?.sortedByDescending { it.lastModified() }?.toList() ?: emptyList()
        previews = files.mapNotNull { f -> decryptToCache(context, f)?.let { f.name to it } }.toMap()
    }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            try { saveEncrypted(context, uri, false); refresh(); error = "Photo safely added to MPG." }
            catch (e: Exception) { error = "Could not import photo: ${e.message}" }
        }
    }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            try { saveEncrypted(context, uri, true); refresh(); error = "Video safely added to MPG." }
            catch (e: Exception) { error = "Could not import video: ${e.message}" }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Accent, background = Bg, surface = Panel,
        onBackground = Txt, onSurface = Txt
    )) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            if (!unlocked) {
                Column(
                    Modifier.fillMaxSize().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("MPG", fontSize = 42.sp, fontWeight = FontWeight.Black, color = Accent)
                    Text("PRIVATE GALLERY", color = Txt, letterSpacing = 3.sp)
                    Spacer(Modifier.height(28.dp))
                    if (setup) {
                        Text("Create your 6-digit PIN", color = Txt)
                        OutlinedTextField(pin, { if (it.length <= 6 && it.all(Char::isDigit)) pin = it },
                            label = { Text("New PIN") }, visualTransformation = PasswordVisualTransformation())
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(confirmPin, { if (it.length <= 6 && it.all(Char::isDigit)) confirmPin = it },
                            label = { Text("Confirm PIN") }, visualTransformation = PasswordVisualTransformation())
                        Button(onClick = {
                            if (pin.length != 6) error = "PIN must be exactly 6 digits."
                            else if (pin != confirmPin) error = "PINs do not match."
                            else {
                                val hash = MessageDigest.getInstance("SHA-256").digest(pin.toByteArray())
                                prefs.edit().putString("pin_hash", Base64.encodeToString(hash, Base64.NO_WRAP)).apply()
                                setup = false; unlocked = true; pin = ""; confirmPin = ""
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Create Secure Gallery") }
                    } else {
                        Text("Enter your PIN", color = Txt)
                        OutlinedTextField(entered, { if (it.length <= 6 && it.all(Char::isDigit)) entered = it },
                            label = { Text("6-digit PIN") }, visualTransformation = PasswordVisualTransformation())
                        Button(onClick = {
                            val hash = MessageDigest.getInstance("SHA-256").digest(entered.toByteArray())
                            val actual = Base64.encodeToString(hash, Base64.NO_WRAP)
                            if (actual == prefs.getString("pin_hash", "")) {
                                unlocked = true; entered = ""; error = ""; refresh()
                            } else error = "Incorrect PIN."
                        }, modifier = Modifier.fillMaxWidth()) { Text("Unlock") }
                        Spacer(Modifier.height(8.dp))
                        TextButton(onClick = {
                            val manager = BiometricManager.from(context)
                            if (manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) != BiometricManager.BIOMETRIC_SUCCESS) {
                                error = "Fingerprint is not available or not enrolled on this device."
                            } else {
                                val activity = context as ComponentActivity
                                val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(context),
                                    object : BiometricPrompt.AuthenticationCallback() {
                                        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                                            unlocked = true; error = ""; refresh()
                                        }
                                        override fun onAuthenticationError(code: Int, msg: CharSequence) { error = msg.toString() }
                                    })
                                prompt.authenticate(BiometricPrompt.PromptInfo.Builder()
                                    .setTitle("Unlock MPG")
                                    .setSubtitle("Use your fingerprint")
                                    .setNegativeButtonText("Cancel")
                                    .build())
                            }
                        }) { Text("Unlock with fingerprint") }
                    }
                    if (error.isNotBlank()) Text(error, color = Color(0xFFFF8A80))
                }
            } else {
                Column(Modifier.fillMaxSize().padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("MPG", color = Accent, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                            Text("Your private space", color = Txt.copy(alpha = .7f))
                        }
                        TextButton(onClick = { unlocked = false; entered = "" }) { Text("Lock") }
                    }
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                            modifier = Modifier.weight(1f)) { Text("+ Photo") }
                        Button(onClick = { videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) },
                            modifier = Modifier.weight(1f)) { Text("+ Video") }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("${files.size} private item(s)", color = Txt)
                    Spacer(Modifier.height(8.dp))
                    if (files.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("Your vault is empty.\nAdd photos or videos to get started.", color = Txt.copy(alpha = .65f))
                        }
                    } else {
                        LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(10.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(files, key = { it.name }) { file ->
                                val preview = previews[file.name]
                                Card(
                                    modifier = Modifier.clickable { selectedFile = file; rotation = 0 },
                                    colors = CardDefaults.cardColors(containerColor = Panel)
                                ) {
                                    Column {
                                        if (preview != null && file.name.contains("photo")) {
                                            AsyncImage(model = preview, contentDescription = "Private photo",
                                                modifier = Modifier.fillMaxWidth().height(145.dp))
                                        } else {
                                            Box(Modifier.fillMaxWidth().height(145.dp).background(Color(0xFF292B36)),
                                                contentAlignment = Alignment.Center) {
                                                Text(if (file.name.contains("video")) "VIDEO" else "PHOTO",
                                                    color = Accent, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Text(if (file.name.contains("video")) "Video" else "Photo",
                                                Modifier.weight(1f), color = Txt)
                                            TextButton(onClick = {
                                                file.delete()
                                                refresh()
                                            }) { Text("Delete", color = Color(0xFFFF8A80)) }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            val activeFile = selectedFile
            if (unlocked && activeFile != null) {
                val preview = previews[activeFile.name]
                if (activeFile.name.contains("video")) {
                    AlertDialog(
                        onDismissRequest = { selectedFile = null },
                        title = { Text("Private video") },
                        text = {
                            if (preview != null) {
                                AndroidView(
                                    factory = { ctx -> VideoView(ctx).apply { setVideoPath(preview.absolutePath); setOnPreparedListener { it.isLooping = false; start() } } },
                                    modifier = Modifier.fillMaxWidth().height(230.dp)
                                )
                            } else Text("Video preview is unavailable.")
                        },
                        confirmButton = { TextButton(onClick = { selectedFile = null }) { Text("Close") } }
                    )
                } else {
                    AlertDialog(
                        onDismissRequest = { selectedFile = null },
                        title = { Text("Edit private photo") },
                        text = {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                if (preview != null) {
                                    AsyncImage(
                                        model = preview,
                                        contentDescription = "Photo preview",
                                        modifier = Modifier.fillMaxWidth().height(260.dp)
                                    )
                                } else Text("Photo preview is unavailable.")
                                Text("Rotate: $rotation°", color = Txt)
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { rotation = (rotation + 90) % 360 }) { Text("Rotate 90°") }
                        },
                        confirmButton = {
                            TextButton(onClick = {
                                if (preview != null && rotation != 0) {
                                    try {
                                        val bitmap = BitmapFactory.decodeFile(preview.absolutePath)
                                        if (bitmap != null) {
                                            val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
                                            val edited = android.graphics.Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
                                            val stream = java.io.ByteArrayOutputStream()
                                            edited.compress(android.graphics.Bitmap.CompressFormat.JPEG, 92, stream)
                                            replaceEncrypted(context, activeFile, stream.toByteArray())
                                            bitmap.recycle(); edited.recycle(); refresh()
                                            error = "Photo rotation saved securely."
                                        }
                                    } catch (e: Exception) { error = "Could not save edit: ${e.message}" }
                                }
                                selectedFile = null
                            }) { Text("Save / Close") }
                        }
                    )
                }
            }
        }
    }
}
